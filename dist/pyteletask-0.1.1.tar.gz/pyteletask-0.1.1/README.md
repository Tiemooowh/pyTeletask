# PyTeletask

How to install
==============
Two standard ways: using pip or calling setup.py manually.
With pip for Python 3 (http://www.pip-installer.org), simply do::

> pip3 install pyteletask

You can optionally add --install-option="--user" to tell setup.py to install in your home rather than in one of the system-wide locations.

The other way: uncompress archive. Then calling setup.py directly boils down to::

> python setup.py install

You can optionally add --user to install in your home.
Please refer to distutils documentation for further details.

Version 0.0.1
=============
Initial release with basic functionality