from .doip_interface import TeletaskDoIPInterface#, ConnectionType, ConnectionConfig
from .client import Client