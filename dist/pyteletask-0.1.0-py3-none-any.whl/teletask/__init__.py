"""Teletask is a Python 3 library for Teletask/DoIP protocol."""
# flake8: noqa
from .teletask import Teletask