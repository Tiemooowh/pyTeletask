"""Teletask is a Python 3 library for Teletask/DoIP protocol."""
# flake8: noqa
from .client import Teletask
# from .core import TelegramQueue
# from .devices import Devices
# from .io import TeletaskDoIPInterface
# from .doip import Telegram, TeletaskConst, TelegramCommand, TelegramFunction, TelegramSetting, TelegramHeartbeat